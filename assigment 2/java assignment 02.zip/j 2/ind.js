//01 //

var num1=prompt(" for additon type first number")
var num2=prompt("type second number")
 alert("The sum of "+num1+" and "+num2+" is "+(+num1 + +num2))

//02 //

var num1=prompt("For subtraction type first number")
var num2=prompt("type second number")
 alert("Rsult  of subtracting "+num1+" from "+num2+" is "+(+num1 - +num2))

//03 //

var num1=prompt("For multiplication type first number")
var num2=prompt("type second number")
alert("Rsult  of multiplying "+num1+" and "+num2+" is "+(+num1 * +num2))

//04 //
var num1=prompt("FOR division type first number")
var num2=prompt("type second number")
alert("Rsult  of dividing "+num1+" by "+num2+" is "+(+num1 / +num2))
    
//05 //

var num1=prompt(" for remindr Enter first num:")
var num2=prompt("Enter the second num:")
var remainder = +num1 / +num2
alert("The remainder of " + num1 + " divided by " + num2+ " is " + remainder);

//06 //

var ticketPrice=prompt(" Enter the ticket price")
var ticketQuantity=prompt("Enter quantity of ticket")
var total=(+ticketPrice * +ticketQuantity)
alert("Total cost to by " + ticketQuantity + " tickets to a movie is " + total +" PKR.")

//07 //

var num=prompt("for any table enter a number")
alert(num+ " X 1 = "+ num * 1)


//08 //

var celsius =prompt("For fahrenhiet Type celsius number ")
var fahrenhiet=(celsius * 9/5 )+32
alert(celsius + " C is " + fahrenhiet+ " F")

var celsius =prompt("For celsius Type fahrenhie number ")
var fahrenhiet=(fahrenhiet -32)*5/9
alert(celsius + " F is " + fahrenhiet + " C ")

//09 //

var priceOfItem1 =prompt("for shopping enter price of item 1 ")
 var priceOfItem2 =prompt("enter price of  item 2")
 var quantity1 =prompt("quantity of item 1")
 var quantity2 =prompt("quantity of item 2")
 var shippinCharges = 900
 var totalCost= (priceOfItem1 * quantity1 + priceOfItem2 * quantity2)+900
 alert("included shippin Charges is " +shippinCharges)
 alert("Totle cost of your order "+ totalCost)

//10 //

var totoalMarks=prompt("ENTER TOTAL MARKS")
var obtainedMark=prompt("ENTER obtained Mark")
var parcentage=(obtainedMark / totoalMarks * 100)
alert(" your percentag is " + parcentage)

//11 //

var doller=prompt("ENTER doller do you have ")
var riyal=prompt("ENTER riyal do you have")
var pakRupee=(doller*296 + riyal*79)
alert("Total currency in PKR " + pakRupee)


//12 //

var num1=prompt("ENTER any number")
var num2=prompt("Enter number which is multiply by the first num")
alert("Arithmetic is " +(+num1 * +num2)/2 )

//13 //

var currentYear=prompt("To find age. ENTER current year ")
var birthYear=prompt("Enter birth year")
alert("Your age is " +( +currentYear - +birthYear))

//14 //

var radius=prompt("TO find area of circle. ENTER the Radius of circle")
var circumfrenece= 2 * 3.142 *radius
var area=3.142 * radius * radius
alert("circumfrenece of circle is "+ circumfrenece)
alert("Area of circle is "+ area )


//15 //

//i//
var a=2
var b=1
var result = --a - --b + ++b + b--;
alert("result of --a - --b + ++b + b-- is = "+result)

//ii//
var a=2
var b=1
var result = --a
alert("result of --a is = "+result)

//iii//
var a=2
var b=1
var result = --a - --b
alert("result of --a - --b is = "+result)

//iv//
var a=2
var b=1
var result = --a - --b + ++b
alert("result of --a - --b + ++b is = "+result)



//16 //

var snack= "Pulao"
var currentAge =21
var maximumAge=80
var estimatedAmountPerday=2
var remaningAge= maximumAge - currentAge
var lifeTimeSnak=remaningAge
var totalsnake= remaningAge*365*estimatedAmountPerday

alert("My currert age is "+currentAge )
alert("Mximum age of 21 century is "+maximumAge)
alert(" I Eat per day plate "+estimatedAmountPerday)
alert("Hammad you will need "+ totalsnake+ " polao to last you. until the rip of old age is 80 ")


//assingment completed//





